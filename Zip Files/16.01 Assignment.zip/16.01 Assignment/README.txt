PROJECT TITLE: 16.01 Transversals
PURPOSE OF PROJECT: To satisfy the requirements of the 16.01 assignment.
VERSION or DATE: 3/25/17
AUTHORS: V. Swaminathan
COMMENTS: This program took me just under an hour to write, and was fairly simple. The only thing is that I accidentally did what was asked for in TestCandidate in TestCandidateV2, and vice versa.