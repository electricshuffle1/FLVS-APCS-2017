PROJECT TITLE: 16.02 Replacements
PURPOSE OF PROJECT: To satisfy the requirements of the 16.02 assignment.
VERSION or DATE: 3/25/17
AUTHORS: V. Swaminathan
COMMENTS: This program took me no time at all to write. This is an algorithm that I have used before in the course, albeit without knowing it.