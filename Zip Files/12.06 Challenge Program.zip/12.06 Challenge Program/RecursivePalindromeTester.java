/**
 * @purpose: To satisfy the requirements of the 12.06 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/22/17
 */

import java.util.Scanner;
public class RecursivePalindromeTester
{
    public static void main(String[] args)
    {
        RecursivePalindrome test = new RecursivePalindrome();
        Scanner in = new Scanner(System.in);
        String palindrome = "radon asa nodar!";

        System.out.println("Enter a word or sentence to check if it is a palindrome: ");
        palindrome = in.nextLine();

        System.out.println("IsStringPalindrome = " + test.checkPalindrome(palindrome));
    }
}