PROJECT TITLE: 12.06 Challenge Program
PURPOSE OF PROJECT: To satisfy the requirements of the 12.06 assignment.
VERSION or DATE: 3/22/17
AUTHORS: V. Swaminathan
COMMENTS: This program was very simple to write; the recursive logic was easy to understand, and testing the program was pretty fun too!