/**
 * @purpose: To satisfy the requirements of the 12.06 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/22/17
 */

public class RecursivePalindrome
{
    public RecursivePalindrome()
    {
        //
    }

    public boolean checkPalindrome(String pal)
    {
        String testMe = pal;
        testMe = helper(testMe);

        if(testMe.length() <= 1)
        {
            return true;
        }
        else if(testMe.charAt(0) == testMe.charAt(testMe.length()-1))
        {
            return checkPalindrome(testMe.substring(1, (testMe.length() - 1)));
        }
        else
        {
            return false;
        }

    }

    public String helper(String pal)
    {
        String makeUniform = pal.toUpperCase();

        if((makeUniform.charAt(makeUniform.length()-1) == '.') || (makeUniform.charAt(makeUniform.length()-1) == '!') || (makeUniform.charAt(makeUniform.length()-1) == '?'))
        {
            makeUniform = makeUniform.substring(0, (makeUniform.length() - 1));
        }

        return makeUniform;
    }
}