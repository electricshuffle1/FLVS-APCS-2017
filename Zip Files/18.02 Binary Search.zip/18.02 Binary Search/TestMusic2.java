/**
 * @purpose: To satisfy the requirements of the 18.02 assignment.
 * 
 * @author V. Swaminathan
 * @version 3/31/17
 */

public class TestMusic2
{
    public static void printMusic(Music[] music)
    {
        System.out.println();
        System.out.println("Music Library: ");
        System.out.println("-------------- ");

        for(Music m : music)
        {
            System.out.println(m.toString());
        }

        System.out.println();
    }

    public static Music[] selectionSortTitle(Music[] myMusic)
    {
        int in = 0;
        int out = 0;
        int posmax = 0;
        Music temp = new Music("", "", 0);
        Music[] music = myMusic;

        for(out = music.length-1; out>=0; out--)
        {
            posmax = 0;
            for(in = 0; in <= out; in++)
            {
                if(music[in].getTitle().compareTo(music[posmax].getTitle()) > 0)
                {
                    posmax = in;
                }

                temp = music[out];
                music[out] = music[posmax];
                music[posmax] = temp;
            }
        }

        return music;
    }

    public static Music[] selectionSortSinger(Music[] myMusic)
    {
        int in = 0;
        int out = 0;
        int posmax = 0;
        Music temp = new Music("", "", 0);
        Music[] music = myMusic;

        for(out = music.length-1; out>=0; out--)
        {
            posmax = 0;
            for(in = 0; in <= out; in++)
            {
                if(music[in].getSinger().compareTo(music[posmax].getSinger()) > 0)
                {
                    posmax = in;
                }

                temp = music[out];
                music[out] = music[posmax];
                music[posmax] = temp;
            }
        }

        return music;
    }

    public static Music[] selectionSortYear(Music[] myMusic)
    {
        int in = 0;
        int out = 0;
        int posmax = 0;
        Music temp = new Music("", "", 0);
        Music[] music = myMusic;

        for(out = music.length-1; out>=0; out--)
        {
            posmax = 0;
            for(in = 0; in <= out; in++)
            {
                if(music[in].getYear() > music[posmax].getYear())
                {
                    posmax = in;
                }

                temp = music[out];
                music[out] = music[posmax];
                music[posmax] = temp;
            }
        }

        return music;
    }

    public static void searchTitle(Music[] music, String toFind)
    {
        int high = music.length;
        int low = -1;
        int probe = 0;

        System.out.println("Search - Title - " + toFind);
        while(high - low > 1)
        {
            probe = (high+low)/2;
            
            if(music[probe].getTitle().compareTo(toFind) > 0)
            {
                high = probe;
            }
            else
            {
                low = probe;
            }
        }

        if((low >= 0) && (music[low].getTitle().compareTo(toFind) == 0))
        {
            System.out.println("Found: " + music[low].toString() + "\n");
        }
        else
        {
            System.out.println("Not Found: " + toFind + "\n");
        }
    }

    public static void searchYear(Music[] music, int toFind)
    {
        int high = music.length;
        int low = -1;
        int probe = 0;

        System.out.println("Search - Year - " + toFind);
        while(high - low > 1)
        {
            probe = (high+low)/2;
            
            if(music[probe].getYear() > toFind)
            {
                high = probe;
            }
            else
            {
                low = probe;
            }
        }

        if((low >= 0) && (music[low].getYear() == toFind))
        {
            System.out.println("Found: " + music[low].toString() + "\n");
        }
        else
        {
            System.out.println("Not Found: " + toFind + "\n");
        }
    }

    public static void searchSinger(Music[] music, String toFind)
    {
        int high = music.length;
        int low = -1;
        int probe = 0;

        System.out.println("Search - Singer - " + toFind);
        while(high - low > 1)
        {
            probe = (high+low)/2;
            
            if(music[probe].getSinger().compareTo(toFind) > 0)
            {
                high = probe;
            }
            else
            {
                low = probe;
            }
        }

        if((low >= 0) && (music[low].getSinger().compareTo(toFind) == 0))
        {
            System.out.println("Found: " + music[low].toString() + "\n");
        }
        else
        {
            System.out.println("Not Found: " + toFind + "\n");
        }
    }
    public static void main(String[] args)
    {
        Music[] myMusic = new Music[10];

        myMusic[0] = new Music("Pieces of You", "Jewel", 1994);
        myMusic[1] = new Music("Jagged Little Pill", "Alanis Morisette", 1995);
        myMusic[2] = new Music("What If It\'s You", "Reba McEntire", 1995);
        myMusic[3] = new Music("Misunderstood", "Pink", 2001);
        myMusic[4] = new Music("Laundry Service", "Shakira", 2001);
        myMusic[5] = new Music("Taking the Long Way", "Dixie Chicks", 2006);
        myMusic[6] = new Music("Under My Skin", "Avril Lavigne", 2004);
        myMusic[7] = new Music("Let Go", "Avril Lavigne", 2002);
        myMusic[8] = new Music("Let It Go", "Tim McGraw", 2007);
        myMusic[9] = new Music("White Flag", "Dido", 2004);

        printMusic(myMusic);

        myMusic = selectionSortTitle(myMusic);
        searchTitle(myMusic, "Let Go");
        searchTitle(myMusic, "Under Paid");

        myMusic = selectionSortYear(myMusic);
        searchYear(myMusic, 2005);
        searchYear(myMusic, 2006);

        myMusic = selectionSortSinger(myMusic);
        searchSinger(myMusic, "Darth Maul");
        searchSinger(myMusic, "Dido");
    }
}