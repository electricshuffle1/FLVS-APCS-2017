PROJECT TITLE: 18.02 Binary Search
PURPOSE OF PROJECT: To satisfy the requirements of the 18.02 assignment.
VERSION or DATE: 4/3/17
AUTHORS: V. Swaminathan
COMMENTS: This program was easy to write, but I had to troubleshoot the sorting algorithms for a little while. It was a simple syntax error which was quickly fixed.