PROJECT TITLE: 18.01 Sequential Search
PURPOSE OF PROJECT: To satisfy the requirements of the 18.01 assignment.
VERSION or DATE: 3/31/17
AUTHORS: V. Swaminathan
COMMENTS: This program was easy to write, as I was able to draw heavily on code written for previous assignments. I have used similar code in C programming for robotics.