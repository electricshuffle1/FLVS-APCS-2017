/**
 * @purpose: To satisfy the requirements of the 18.01 assignment.
 * 
 * @author V. Swaminathan
 * @version 3/31/17
 */

public class Music
{
    private String title, singer;
    private int year;

    public Music(String title, String singer, int year)
    {
        this.title = title;
        this.singer = singer;
        this.year = year;
    }

    public String getTitle()
    {
        return title;
    }

    public String getSinger()
    {
        return singer;
    }

    public int getYear()
    {
        return year;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public void setSinger(String singer)
    {
        this.singer = singer;
    }

    public void setYear(int year)
    {
        this.year = year;
    }

    public String toString()
    {
        return title + ", " + year + ", " + singer;
    }
}