/**
 * @purpose: To satisfy the requirements of the 18.01 assignment.
 * 
 * @author V. Swaminathan
 * @version 3/31/17
 */

public class TestMusic
{
    public static void printMusic(Music[] music)
    {
        System.out.println();

        for(Music m : music)
        {
            System.out.println(m.toString());
        }

        System.out.println();
    }

    public static void searchTitle(Music[] music, String toFind)
    {
        int found = -1;

        System.out.println("Search - Title - " + toFind);

        for(int i = 0; i < music.length; i++)
        {
            if(music[i].getTitle().equals(toFind))
            {
                found = i;
                break;
            }
        }

        if(found != -1)
        {
            System.out.println("We found " + toFind + " in the library:");
            System.out.println(music[found].toString());
        }
        else
        {
            System.out.println(toFind + " is not in the library");
        }

        System.out.println();
    }

    public static void searchYear(Music[] music, int toFind)
    {
        int found = 0;

        System.out.println("Search - Year - " + toFind);
        System.out.println("Find Results: ");

        for(int i = 0; i < music.length; i++)
        {
            if(music[i].getYear() == toFind)
            {
                found++;
                System.out.println(music[i].toString());
            }
        }

        if(found != -1)
        {
            System.out.println("There were " + found + " listings for " + toFind);
        }
        else
        {
            System.out.println("There are no listings for " + toFind);
        }

        System.out.println();
    }

    public static void searchSinger(Music[] music, String toFind)
    {
        int found = 0;

        System.out.println("Search - Singer - " + toFind);
        System.out.println("Find Results: ");

        for(int i = 0; i < music.length; i++)
        {
            if(music[i].getSinger().equals(toFind))
            {
                found++;
                System.out.println(music[i].toString());
            }
        }

        if(found != 0)
        {
            System.out.println("There were " + found + " listings for " + toFind);
        }
        else
        {
            System.out.println("There are no listings for " + toFind);
        }

        System.out.println();
    }
    public static void main(String[] args)
    {
        Music[] myMusic = new Music[10];

        myMusic[0] = new Music("Pieces of You", "Jewel", 1994);
        myMusic[1] = new Music("Jagged Little Pill", "Alanis Morisette", 1995);
        myMusic[2] = new Music("What If It\'s You", "Reba McEntire", 1995);
        myMusic[3] = new Music("Misunderstood", "Pink", 2001);
        myMusic[4] = new Music("Laundry Service", "Shakira", 2001);
        myMusic[5] = new Music("Taking the Long Way", "Dixie Chicks", 2006);
        myMusic[6] = new Music("Under My Skin", "Avril Lavigne", 2004);
        myMusic[7] = new Music("Let Go", "Avril Lavigne", 2002);
        myMusic[8] = new Music("Let It Go", "Tim McGraw", 2007);
        myMusic[9] = new Music("White Flag", "Dido", 2004);

        printMusic(myMusic);

        searchTitle(myMusic, "Let Go");
        searchTitle(myMusic, "Some Day");
        searchYear(myMusic, 2001);
        searchYear(myMusic, 2003);
        searchSinger(myMusic, "Avril Lavigne");
        searchSinger(myMusic, "Tony Curtis");
    }
}