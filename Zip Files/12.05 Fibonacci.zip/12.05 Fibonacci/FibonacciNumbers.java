/**
 * @purpose: To satisfy the requirements of the 12.05 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/22/17
 */

public class FibonacciNumbers
{
    public FibonacciNumbers()
    {
        //
    }

    public int calcNum(int num)
    {
        if(num == 0)
        {
            return 0;
        }
        else if(num == 1)
        {
            return 1;
        }
        else
        {
            return calcNum(num - 1) + calcNum(num - 2);
        }
    }
}