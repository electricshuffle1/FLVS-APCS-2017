PROJECT TITLE: 12.05 Fibonacci Numbers
PURPOSE OF PROJECT: To satisfy the requirements of the 12.05 assignment.
VERSION or DATE: 3/22/17
AUTHORS: V. Swaminathan
COMMENTS: This program was easy to write using recursive methods. The only issue I had was having to use a separate debugger from VS Code, as the standard debugger in this IDE can't handle inputs.