/**
 * @purpose: To satisfy the requirements of the 12.05 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/22/17
 */

import java.util.Scanner;

public class FibonacciTester
{
    public static void main(String[] args)
    {
        FibonacciNumbers test = new FibonacciNumbers();
        Scanner in = new Scanner(System.in);

        String tempNum = " ";
        int number = 0;

        System.out.println("------------------------ Fibonacci Numbers ------------------------");
        System.out.println("How to Use: enter the n\'th Fibonacci number you wish to know,     ");
        System.out.println("            and press \'q\' to exit the program. Enjoy!            ");
        System.out.println();

        //Use below line to test methods
        //System.out.println(test.calcNum(15));

        while(tempNum.equalsIgnoreCase("q") == false)
        {
            System.out.println("Enter Term: ");
            tempNum = in.next();
            number = Integer.parseInt(tempNum);
            System.out.println("This term is: " + test.calcNum(number));
            System.out.println();
        }

    }
}