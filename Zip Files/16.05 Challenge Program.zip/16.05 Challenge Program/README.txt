PROJECT TITLE: 16.05 Challenge Program
PURPOSE OF PROJECT: To satisfy the requirements of the 16.05 assignment.
VERSION or DATE: 3/25/17
AUTHORS: V. Swaminathan
COMMENTS: This program took me an hour and a half to write, but most of that time was spent going back and commenting code, not actually debugging. I used an arraylist for the students, as this is what I am most comfortable with, and made some modifications to the code in order to improve efficiency. Still, there may be some code that could be trimmed down. Overall, I felt confident about this program.