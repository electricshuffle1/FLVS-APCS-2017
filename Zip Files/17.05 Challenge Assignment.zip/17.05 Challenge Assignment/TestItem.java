/**
 * @purpose: To satisfy the requirements of the 17.05 Challenge Assignment.
 * 
 * @author V. Swaminathan
 * @version 3/26/17
 */

public class TestItem
{
    //I will use a standard array here to show that I am not using ArrayLists as a crutch
    private static Item[] hardware = new Item[6];

    public static void printInventory()
    {
        System.out.printf("\n%6s%2s%12s%2s%7s%4s%5s\n", "itemID", " ", "itemName", " ", "inStore", " ", "price");
        System.out.println("---------------------------------------------------");

        for(Item x : hardware)
            System.out.println(x.toString());
        
    }

    public static void sortID() //Insertion sort
    {
        Item[] dest = new Item[hardware.length];

        for(int i = 0; i < hardware.length; i++)
        {
            Item next = hardware[i];
            int insertIndex = 0;
            int k = i;

            while(k > 0 && insertIndex == 0)
            {
                if(next.getItemID().compareTo(dest[k - 1].getItemID()) > 0)
                {
                    insertIndex = k;
                }
                else
                {
                    dest[k] = dest[k-1];
                }
                k--;
            }

            dest[insertIndex] = next;
        }
        
        hardware = dest;
    }

    public static void sortName() //Insertion sort
    {
        Item[] dest = new Item[hardware.length];

        for(int i = 0; i < hardware.length; i++)
        {
            Item next = hardware[i];
            int insertIndex = 0;
            int k = i;

            while(k > 0 && insertIndex == 0)
            {
                if(next.getItemName().compareTo(dest[k - 1].getItemName()) > 0)
                {
                    insertIndex = k;
                }
                else
                {
                    dest[k] = dest[k-1];
                }
                k--;
            }

            dest[insertIndex] = next;
        }
        
        hardware = dest;
    }

    public static void sortInStore() //Selection sort
    {
        int out = 0;
        int in = 0;
        int posmax = 0;
        Item temp = new Item("", "", 0, 0);

        for(out = hardware.length-1; out >= 0; out--)
        {
            posmax = 0;
            for(in = 0; in <= out; in++)
            {
                if(hardware[in].getInStore() > hardware[posmax].getInStore())
                {
                    posmax = in;
                }
            }

            temp = hardware[out];
            hardware[out] = hardware[posmax];
            hardware[posmax] = temp;
        }
    }

    public static void sortPrice(int low, int high) //Merge sort
    {
        if(low == high)
            return;
        
        int mid = (low + high)/2;

        sortPrice(low, mid);
        sortPrice(mid+1, high);
        mergePrice(low, mid, high);
    }

    public static void mergePrice(int low, int mid, int high) //Merge sort helper
    {
        Item[] temp = new Item[high - low + 1];

        int i = low;
        int j = mid + 1;
        int n = 0;

        while(i <= mid || j <= high)
        {
            if(i > mid)
            {
                temp[n] = hardware[j];
                j++;
            }
            else if(j > high)
            {
                temp[n] = hardware[i];
                i++;
            }
            else if(hardware[i].getPrice() > hardware[j].getPrice())
            {
                temp[n] = hardware[i];
                i++;
            }
            else
            {
                temp[n] = hardware[j];
                j++;
            }
            n++;
        }

        for(int k = low; k <= high; k++)
            hardware[k] = temp[k-low];
    }

    public static void main(String[] args)
    {
        hardware[0] = new Item("1011", "Air Filters", 200, 10.5);
        hardware[1] = new Item("1034", "Door Knobs", 60, 21.5);
        hardware[2] = new Item("1101", "Hammers", 90, 9.99);
        hardware[3] = new Item("1600", "Levels", 80, 19.99);
        hardware[4] = new Item("1500", "Ceiling Fans", 100, 59);
        hardware[5] = new Item("1201", "Wrench Sets", 55, 80);

        System.out.println("\nOriginal Array: ");
        printInventory();

        System.out.println("\nSorted by ID: ");
        sortID();
        printInventory();

        System.out.println("\nSorted by Name: ");
        sortName();
        printInventory();

        System.out.println("\nSorted by inStore: ");
        sortInStore();
        printInventory();

        System.out.println("\nSorted by Price: ");
        sortPrice(0, hardware.length-1);
        printInventory();

    }
}