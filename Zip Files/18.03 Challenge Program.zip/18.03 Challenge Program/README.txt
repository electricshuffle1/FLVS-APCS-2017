PROJECT TITLE: 18.03 Challenge Program
PURPOSE OF PROJECT: To satisfy the requirements of the 18.03 assignment.
VERSION or DATE: 4/3/17
AUTHORS: V. Swaminathan
COMMENTS: This program took very little time to finish, and needed no debugging at all. I feel very confident and comfortable with binary search, sequential search, and sequential sorting.