/**
 * @purpose: 
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public class MyScience extends Homework
{
    public MyScience()
    {
        super();
    }

    public void createAssignment(int pr)
    {
        setPagesRead(pr);
        setTypeHomework("Science");
    }

    public String toString()
    {
        return getTypeHomework() + " - must read " + getPagesRead() + " pages.";
    }
}