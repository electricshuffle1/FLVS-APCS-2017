/**
 * @purpose: 
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public abstract class Homework
{
    private int pagesRead;
    private String typeHomework;

    public Homework()
    {
        pagesRead = 0;
        typeHomework = "none";
    }

    public int getPagesRead()
    {
        return pagesRead;
    }

    public void setPagesRead(int s)
    {
        pagesRead = s;
    }

    public String getTypeHomework()
    {
        return typeHomework;
    }

    public void setTypeHomework(String t)
    {
        typeHomework = t;
    }

    public abstract void createAssignment(int p);

}