/**
 * @purpose: 
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public class MyJava extends Homework
{
    public MyJava()
    {
        super();
    }

    public void createAssignment(int pr)
    {
        setPagesRead(pr);
        setTypeHomework("Java");
    }

    public String toString()
    {
        return getTypeHomework() + " - must read " + getPagesRead() + " pages.";
    }
}