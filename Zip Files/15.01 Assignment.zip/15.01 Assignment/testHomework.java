/**
 * @purpose: 
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

import java.util.ArrayList;

public class testHomework
{

    public static void main(String[] args)
    {
        ArrayList<Homework> hw = new ArrayList<Homework>();

        hw.add(new MyMath());
        hw.add(new MyScience());
        hw.add(new MyEnglish());
        hw.add(new MyJava());

        hw.get(0).createAssignment(4);
        hw.get(1).createAssignment(6);
        hw.get(2).createAssignment(10);
        hw.get(3).createAssignment(5);

        for(Homework i : hw)
        {
            System.out.println(i.toString());
        }
    }
}