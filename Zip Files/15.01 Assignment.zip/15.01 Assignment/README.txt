PROJECT TITLE: 15.01 Abstract Classes
PURPOSE OF PROJECT: To satisfy the requirements of the 15.01 assignment.
VERSION or DATE: 3/20/17
AUTHORS: V. Swaminathan
COMMENTS: The only issue I had with this code was debugging the return type of the overriding toString() methods; I had initially set them to void, when they should have been String.