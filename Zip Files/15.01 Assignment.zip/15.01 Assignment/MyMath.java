/**
 * @purpose: 
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public class MyMath extends Homework
{
    public MyMath()
    {
        super();
    }

    public void createAssignment(int pr)
    {
        setPagesRead(pr);
        setTypeHomework("Math");
    }

    public String toString()
    {
        return getTypeHomework() + " - must read " + getPagesRead() + " pages.";
    }
}