/**
 * @purpose: 
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public class MyEnglish extends Homework
{
    public MyEnglish()
    {
        super();
    }

    public void createAssignment(int pr)
    {
        setPagesRead(pr);
        setTypeHomework("English");
    }

    public String toString()
    {
        return getTypeHomework() + " - must read " + getPagesRead() + " pages.";
    }
}