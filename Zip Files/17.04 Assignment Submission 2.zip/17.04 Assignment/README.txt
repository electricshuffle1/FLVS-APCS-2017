PROJECT TITLE: 17.04 Merge Sorting
PURPOSE OF PROJECT: To satisfy the requirements of the 17.04 assignment.
VERSION or DATE: 3/26/17
AUTHORS: V. Swaminathan
COMMENTS: This program was harder to understand for me, and I am still going over how the algorithm work in depth. I do feel somewhat confident in implementing the algorithm however.
