/**
 * @purpose: To satisfy the requirements of the 15.04 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public interface Processing
{
    public abstract void doReading();
}