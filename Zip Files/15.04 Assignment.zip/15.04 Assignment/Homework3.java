/**
 * @purpose: To satisfy the requirements of the 15.04 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/21/17
 */

public abstract class Homework3 implements Processing, Comparable<Homework3>
{
    private int pagesRead;
    private String typeHomework;

    public Homework3()
    {
        pagesRead = 0;
        typeHomework = "none";
    }

    public int getPagesRead()
    {
        return pagesRead;
    }

    public void setPagesRead(int s)
    {
        pagesRead = s;
    }

    public String getTypeHomework()
    {
        return typeHomework;
    }

    public void setTypeHomework(String t)
    {
        typeHomework = t;
    }

    public int compareTo(Homework3 a)
    {
        if(a.getPagesRead() == getPagesRead())
        {
            return 0;
        }
        else if(a.getPagesRead() > getPagesRead())
        {
            return 1;
        }
        else
        {
            return -1;
        }
    }

    public abstract void createAssignment(int p);

}