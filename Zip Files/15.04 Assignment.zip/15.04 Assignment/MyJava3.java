/**
 * @purpose: To satisfy the requirements of the 15.03 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public class MyJava3 extends Homework3
{
    public MyJava3()
    {
        super();
    }

    public void createAssignment(int pr)
    {
        setPagesRead(pr);
        setTypeHomework("Java");
    }

    public String toString()
    {
        return getTypeHomework() + " - must read " + getPagesRead() + " pages.";
    }

    public void doReading()
    {
        int x = getPagesRead();
        setPagesRead((x-4));
    }
}