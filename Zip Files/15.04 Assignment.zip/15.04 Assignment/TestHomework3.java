/**
 * @purpose: To satisfy the requirements of the 15.03 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

import java.util.ArrayList;
import java.util.List;
public class TestHomework3
{
    public static void main(String[] args)
    {
        List<Homework3> hw = new ArrayList<Homework3>();

        hw.add(new MyMath3());
        hw.add(new MyScience3());
        hw.add(new MyEnglish3());
        hw.add(new MyJava3());

        hw.get(0).createAssignment(4);
        hw.get(1).createAssignment(6);
        hw.get(2).createAssignment(10);
        hw.get(3).createAssignment(5);

        for(Homework3 i : hw)
        {
            System.out.println(i.toString());
        }

        //Compare index vars --> allows for quick selection of object in array for comparison
        int x = 3;
        int y = 2;

        if(hw.get(x).compareTo(hw.get(y)) == 0)
            System.out.println("The homework for " + hw.get(x).getTypeHomework() + " and " + hw.get(y).getTypeHomework() + " are the same number of pages");
        else if(hw.get(x).compareTo(hw.get(y)) == 1)
            System.out.println("The homework for " + hw.get(x).getTypeHomework() + " has more pages than the homework for " + hw.get(y).getTypeHomework());
        else
            System.out.println("The homework for " + hw.get(x).getTypeHomework() + " has less pages than the homework for " + hw.get(y).getTypeHomework());

    }
}