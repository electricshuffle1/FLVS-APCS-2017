/**
 * @purpose: To satisfy the requirements of the 15.04 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/21/17
 */

public class MyMath3 extends Homework3
{
    public MyMath3()
    {
        super();
    }

    public void createAssignment(int pr)
    {
        setPagesRead(pr);
        setTypeHomework("Math");
    }

    public String toString()
    {
        return getTypeHomework() + " - must read " + getPagesRead() + " pages.";
    }

    public void doReading()
    {
        int x = getPagesRead();
        setPagesRead((x-2));
    }
}