PROJECT TITLE: 15.04 Interfaces
PURPOSE OF PROJECT: To satisfy the requirements of the 15.04 assignment.
VERSION or DATE: 3/21/17
AUTHORS: V. Swaminathan
COMMENTS: This program mostly reused code from the previous assignment, and took very little work to modify in order to implement the Comparable<t> interface and its associated logic.