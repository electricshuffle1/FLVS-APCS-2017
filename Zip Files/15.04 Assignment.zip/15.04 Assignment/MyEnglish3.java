/**
 * @purpose: To satisfy the requirements of the 15.04 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/21/17
 */

public class MyEnglish3 extends Homework3
{
    public MyEnglish3()
    {
        super();
    }

    public void createAssignment(int pr)
    {
        setPagesRead(pr);
        setTypeHomework("English");
    }

    public String toString()
    {
        return getTypeHomework() + " - must read " + getPagesRead() + " pages.";
    }

    public void doReading()
    {
        int x = getPagesRead();
        setPagesRead((x-1));
    }
}