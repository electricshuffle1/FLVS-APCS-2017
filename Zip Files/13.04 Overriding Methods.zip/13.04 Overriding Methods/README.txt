PROJECT TITLE: 13.04 Overriding Methods
PURPOSE OF PROJECT: To satisfy the requirements of the 13.04 assignment.
VERSION or DATE: 3/20/17
AUTHORS: V. Swaminathan
COMMENTS: This program was very simple to write. The only debugging I had to do was correcting the calls to find variable values, as I could not call private variables outside of their classes. I changed the statements to use accessor methods, so that they would be class independent.