PROJECT TITLE: 15.03 Interfaces
PURPOSE OF PROJECT: To satisfy the requirements of the 15.03 assignment.
VERSION or DATE: 3/20/17
AUTHORS: V. Swaminathan
COMMENTS: I had no issues in writing this program. However, I reworked the print statement format from what was shown on the assignment instructions, as the provided example seemed to cluttered to follow.