/**
 * @purpose: To satisfy the requirements of the 15.03 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

import java.util.ArrayList;
import java.util.List;
public class TestHomework2
{
    public static void main(String[] args)
    {
        List<Homework2> hw = new ArrayList<Homework2>();

        hw.add(new MyMath2());
        hw.add(new MyScience2());
        hw.add(new MyEnglish2());
        hw.add(new MyJava2());

        hw.get(0).createAssignment(4);
        hw.get(1).createAssignment(6);
        hw.get(2).createAssignment(10);
        hw.get(3).createAssignment(5);

        //Before reading
        System.out.println("Before Reading: \n");

        for(Homework2 i : hw)
        {
            System.out.println(i.toString());
        }

        //After Reading
        System.out.println("\nAfter Reading: \n");

        for(Homework2 i : hw)
        {
            i.doReading();
            System.out.println(i.toString());
        }
    }
}