/**
 * @purpose: To satisfy the requirements of the 15.03 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public class MyMath2 extends Homework2
{
    public MyMath2()
    {
        super();
    }

    public void createAssignment(int pr)
    {
        setPagesRead(pr);
        setTypeHomework("Math");
    }

    public String toString()
    {
        return getTypeHomework() + " - must read " + getPagesRead() + " pages.";
    }

    public void doReading()
    {
        int x = getPagesRead();
        setPagesRead((x-2));
    }
}