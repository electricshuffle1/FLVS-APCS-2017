/**
 * @purpose: To satisfy the requirements of the 13.01 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public class TestTriangles
{
    TestTriangles()
    {
        //constructor
    }

    public static void main(String[] args)
    {
        Triangle tri01 = new Triangle(4, 5, 6);
        Equilateral tri02 = new Equilateral(5);
        IsoscelesRight tri03 = new IsoscelesRight(1.5);

        System.out.println("Triangle has sides A = " + tri01.getSideA() + ", B = " + tri01.getSideB() + ", C = " + tri01.getSideC());
        System.out.println("Equilateral Triangle has sides A = " + tri02.getSideA() + ", B = " + tri02.getSideB() + ", C = " + tri02.getSideC());
        System.out.println("Isosceles Right Triangle has sides A = " + tri03.getSideA() + ", B = " + tri03.getSideB() + ", C = " + tri03.getSideC());


    }
}