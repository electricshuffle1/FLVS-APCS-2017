PROJECT TITLE: 13.01 Class Extensions
PURPOSE OF PROJECT: To satisfy the requirements of the 13.01 assignment.
VERSION or DATE: 3/20/17
AUTHORS: V. Swaminathan
COMMENTS: This program was very easy to understand and write. I like how Java allows me to reuse the same methods from classes, even when extending classes that are extensions in and of themselves. I had no issues in this assignment.