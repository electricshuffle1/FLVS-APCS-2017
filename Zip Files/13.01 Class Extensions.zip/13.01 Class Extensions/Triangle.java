/**
 * @purpose: To satisfy the requirements of the 13.01 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public class Triangle
{
    private double sideA, sideB, sideC;

    Triangle(double a, double b, double c)
    {
        sideA = a;
        sideB = b;
        sideC = c;
    }

    public double getSideA()
    {
        return sideA;
    }

    public double getSideB()
    {
        return sideB;
    }

    public double getSideC()
    {
        return sideC;
    }
}