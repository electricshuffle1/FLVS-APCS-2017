/**
 * @purpose:
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public class TestCube
{
    TestCube()
    {
        //constructor
    }

    public static void main(String[] args)
    {
        Cube testCube = new Cube(3);

        System.out.println("Cube's dimensions are " + testCube.getLength() + " X " + testCube.getWidth() + " X " + testCube.getHeight());
        
    }
}