/**
 * @purpose: To satisfy the requirements of the 13.01 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public class IsoscelesRight extends Triangle
{
    IsoscelesRight(double leg)
    {
        super(leg, leg, (Math.sqrt(2)*leg));
    }
}