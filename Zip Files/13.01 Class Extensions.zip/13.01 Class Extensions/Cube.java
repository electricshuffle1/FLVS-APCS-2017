/**
 * @purpose: To satisfy the requirements of the 13.01 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 * 
 */

public class Cube extends Box
{
    Cube(int side)
    {
        super(side, side, side);
    }
    
}