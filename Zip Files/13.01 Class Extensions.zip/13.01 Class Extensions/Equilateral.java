/**
 * @purpose: To satisfy the requirements of the 13.01 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public class Equilateral extends Triangle
{
    Equilateral(double side)
    {
        super(side, side, side);
    }
}