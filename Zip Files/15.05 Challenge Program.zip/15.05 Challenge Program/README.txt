PROJECT TITLE: 15.05 Challenge Program
PURPOSE OF PROJECT: To satisfy the requirements of the 15.05 assignment.
VERSION or DATE: 3/21/17
AUTHORS: V. Swaminathan
COMMENTS: This program took me a long time for one reason - debugging my ArrayLists. I couldn't make an ArrayList of the interface Product, and I couldn't access the methods of the classes if I left the object type blank in the List declaration (since the default is the Object class), so I ended up making a workaround for the bug using two ArrayLists, one for vehicles and one for tools. This was the simplest way I could figure out how to solve this issue, but there has to be another way. Any help would be appreciated!