/**
 * @purpose: To satisfy the requirements of the 14.02 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/23/17
 */
import java.io.IOException;
import java.util.Scanner;
public class MorseCodeTester
{
    public static void main(String[] args) throws IOException
    {
        Scanner in = new Scanner(System.in);
        String myMessage = " ";

        System.out.println("Type message to translate into Morse Code (omitting punctuation): ");
        myMessage = in.nextLine();
        System.out.println("Your message is: ");
        System.out.println(MorseCode.getTranslation(myMessage));
    }
}