/**
 * @purpose: To satisfy the requirements of the 14.02 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/23/17
 */
import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

public class MorseCode
{
    public MorseCode()
    {
        //
    }

    public static String getTranslation(String morse) throws IOException
    {
        Scanner inFile = new Scanner(new File("Morse.txt"));
        String token = " ";
        List<String> conv = new ArrayList<String>();

        while(inFile.hasNext())
        {
            token = inFile.nextLine();
            conv.add(token);
        }
        inFile.close();

        Scanner text = new Scanner(morse.toUpperCase());
        String morseCodeTranslation = " ";
        char temp = ' ';
        List<Character> letNums = new ArrayList<Character>();
        letNums.add('A');
        letNums.add('B');
        letNums.add('C');
        letNums.add('D');
        letNums.add('E');
        letNums.add('F');
        letNums.add('G');
        letNums.add('H');
        letNums.add('I');
        letNums.add('J');
        letNums.add('K');
        letNums.add('L');
        letNums.add('M');
        letNums.add('N');
        letNums.add('O');
        letNums.add('P');
        letNums.add('Q');
        letNums.add('R');
        letNums.add('S');
        letNums.add('T');
        letNums.add('U');
        letNums.add('V');
        letNums.add('W');
        letNums.add('X');
        letNums.add('Y');
        letNums.add('Z');
        letNums.add('1');
        letNums.add('2');
        letNums.add('3');
        letNums.add('4');
        letNums.add('5');
        letNums.add('6');
        letNums.add('7');
        letNums.add('8');
        letNums.add('9');
        letNums.add('0');
               

        //Loop for generating morse code.
        while(text.hasNext())
        {
            token = text.next();
            
            for(int i = 0; i < token.length(); i++)
            {
                temp = token.charAt(i);
                morseCodeTranslation += conv.get(letNums.indexOf(temp)) + "   ";
                               
            }

            morseCodeTranslation += "     ";
        }

        return morseCodeTranslation;
    }
}