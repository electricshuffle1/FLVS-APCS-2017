PROJECT TITLE: 14.02 Static Methods
PURPOSE OF PROJECT: To satisfy the requirements of the 14.02 assignment.
VERSION or DATE: 3/23/17
AUTHORS: V. Swaminathan
COMMENTS: This program had simple logic, but debugging took longer than any program I have ever written. The main problem I had was with the ArrayLists I used for storing String and char values. I could not get the addAll() method to work with the Character wrapper, so I simply added each character manually into the array. I also kept getting the error "non-static variable cannot be used in a static class" which only went away when I rewrote the entire class into one method with all variables inside. Overall it was painful.