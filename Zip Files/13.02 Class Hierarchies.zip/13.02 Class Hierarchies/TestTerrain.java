/**
 * @purpose: To satisfy the requirements of the 13.02 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public class TestTerrain
{
    TestTerrain()
    {
        //constructor
    }

    public static void main(String[] args)
    {
        Forest forest = new Forest(100, 200, 100);
        Mountain mnt01 = new Mountain(300, 400, 25);
        WinterMountain mnt02 = new WinterMountain(500, 600, 15, 10.0);

        System.out.println("Forest " + forest.terrainSize() + " and has " + forest.getTrees() + " trees.");
        System.out.println("Mountain " + mnt01.terrainSize() + " and has " + mnt01.getMountains() + " mountains.");
        System.out.println("Winter Mountain " + mnt02.terrainSize() + " and has temperature " + mnt02.getTemp() + " and " + mnt02.getMountains() + " mountains.");

    }
}