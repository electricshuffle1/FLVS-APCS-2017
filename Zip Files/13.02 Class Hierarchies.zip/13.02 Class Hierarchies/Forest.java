/**
 * @purpose: To satisfy the requirements of the 13.02 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public class Forest extends Terrain
{
    private int myTrees;

    Forest(int l, int w, int trees)
    {
        super(l, w);
        myTrees = trees;
    }

    public int getTrees()
    {
        return myTrees;
    }
}