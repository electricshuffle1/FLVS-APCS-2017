PROJECT TITLE: 13.02 Class Hierarchies
PURPOSE OF PROJECT: To satisfy the requirements of the 13.02 assignment.
VERSION or DATE: 3/20/17
AUTHORS: V. Swaminathan
COMMENTS: This program was similar to the previous assignment, and was just as simple to write. I had no issues with following the assignment or writing the code.