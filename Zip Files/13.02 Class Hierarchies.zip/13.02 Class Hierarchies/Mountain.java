/**
 * @purpose: To satisfy the requirements of the 13.02 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public class Mountain extends Terrain
{
    private int mountains;

    Mountain(int l, int w, int mnts)
    {
        super(l, w);
        mountains = mnts;
    }

    public int getMountains()
    {
        return mountains;
    }
}