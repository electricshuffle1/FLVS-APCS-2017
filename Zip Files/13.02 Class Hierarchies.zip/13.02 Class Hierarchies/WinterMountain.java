/**
 * @purpose: To satisfy the requirements of the 13.02 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/20/17
 */

public class WinterMountain extends Mountain
{
    private double myTemperature;

    WinterMountain(int l, int w, int mnts, double temp)
    {
        super(l, w, mnts);
        myTemperature = temp;
    }

    public double getTemp()
    {
        return myTemperature;
    }
}