PROJECT TITLE: 17.03 Selection Sorting
PURPOSE OF PROJECT: To satisfy the requirements of the 17.03 assignment.
VERSION or DATE: 3/26/17
AUTHORS: V. Swaminathan
COMMENTS: This program was much easier to understand for me, as this is generally how I think of sorting when I do it by hand. I was able to quickly modify the program to meet the requirements of the assignment.