/**
 * @purpose: To satisfy the requirements of the 17.02 assignment.
 * 
 * @author V. Swaminathan
 * @version 3/26/17
 */

public class TestMovie2
{
    private static Movie2[] myMovies = new Movie2[10];

    /**
     * @method: printMovies = prints out the toString() info for each element in myMovies
     * 
     * @param null
     */
    public static void printMovies()
    {
        for(Movie2 m : myMovies)
        {
            System.out.println(m.toString());
        }
    }

    /**
     * @method: sortTitles = sorts elements in myMovies by title, order determined by user
     * 
     * @param ordering = selector for order of sort (ascending = 1, descending = 2)
     */
    public static void sortTitles(int ordering)
    {
        Movie2[] dest = new Movie2[myMovies.length];

        for(int i = 0; i < myMovies.length; i++)
        {
            Movie2 next = myMovies[i];
            int insertIndex = 0;
            int k = i;

            while(k > 0 && insertIndex == 0)
            {
                if(ordering == 1)
                {
                    if(next.getTitle().compareTo(dest[k - 1].getTitle()) > 0)
                    {
                        insertIndex = k;
                    }
                    else
                    {
                        dest[k] = dest[k-1];
                    }
                }
                else
                {
                    if(next.getTitle().compareTo(dest[k - 1].getTitle()) < 0)
                    {
                        insertIndex = k;
                    }
                    else
                    {
                        dest[k] = dest[k-1];
                    }
                }
                k--;
            }

            dest[insertIndex] = next;
        }
        
        myMovies = dest;
    }

    /**
     * @method: sortYears = sorts elements in myMovies by year, order determined by user
     * 
     * @param ordering = selector for order of sort (ascending = 1, descending = 2)
     */
    public static void sortYears(int ordering)
    {
        Movie2[] dest = new Movie2[myMovies.length];

        for(int i = 0; i < myMovies.length; i++)
        {
            Movie2 next = myMovies[i];
            int insertIndex = 0;
            int k = i;

            while(k > 0 && insertIndex == 0)
            {
                if(ordering == 1)
                {
                    if(next.getYear() > dest[k - 1].getYear())
                    {
                        insertIndex = k;
                    }
                    else
                    {
                        dest[k] = dest[k-1];
                    }
                }
                else
                {
                    if(next.getYear() < dest[k - 1].getYear())
                    {
                        insertIndex = k;
                    }
                    else
                    {
                        dest[k] = dest[k-1];
                    }
                }
                k--;
            }

            dest[insertIndex] = next;
        }
        
        myMovies = dest;
    }

    /**
     * @method: sortStudios = sorts elements in myMovies by studio, order determined by user
     * 
     * @param ordering = selector for order of sort (ascending = 1, descending = 2)
     */
    public static void sortStudios(int ordering)
    {
        Movie2[] dest = new Movie2[myMovies.length];

        for(int i = 0; i < myMovies.length; i++)
        {
            Movie2 next = myMovies[i];
            int insertIndex = 0;
            int k = i;

            while(k > 0 && insertIndex == 0)
            {
                if(ordering == 1)
                {
                    if(next.getStudio().compareTo(dest[k - 1].getStudio()) > 0)
                    {
                        insertIndex = k;
                    }
                    else
                    {
                        dest[k] = dest[k-1];
                    }
                }
                else
                {
                    if(next.getStudio().compareTo(dest[k - 1].getStudio()) < 0)
                    {
                        insertIndex = k;
                    }
                    else
                    {
                        dest[k] = dest[k-1];
                    }
                }
                k--;
            }

            dest[insertIndex] = next;
        }
        
        myMovies = dest;
    }
    public static void main(String[] args)
    {
        myMovies[0] = new Movie2("The Muppets Take Manhattan", "Columbia Tristar", 2001);
        myMovies[1] = new Movie2("Mulan Special Edition", "Disney", 2004);
        myMovies[2] = new Movie2("Shrek 2", "Dreamworks", 2004);
        myMovies[3] = new Movie2("The Incredibles", "Pixar", 2004);
        myMovies[4] = new Movie2("Nanny McPhee", "Universal", 2006);
        myMovies[5] = new Movie2("The Curse of the Were-Rabbit", "Aardman", 2006);
        myMovies[6] = new Movie2("Ice Age", "20th Century Fox", 2002);
        myMovies[7] = new Movie2("Lilo & Stitch", "Disney", 2002);
        myMovies[8] = new Movie2("Robots", "20th Century Fox", 2005);
        myMovies[9] = new Movie2("Monsters Inc.", "Pixar", 2001);

        //First print
        System.out.println("\nBefore Sorting: ");
        printMovies();
        System.out.println();

        //Sorted by Title - ascending
        System.out.println("\nSorted by Title - ascending: ");
        sortTitles(1);
        printMovies();
        System.out.println();

        //Sorted by Year - descending
        System.out.println("\nSorted by Year - descending: ");
        sortYears(2);
        printMovies();
        System.out.println();

        //Sorted by Studio - ascending
        System.out.println("\nSorted by Studio - ascending: ");
        sortStudios(1);
        printMovies();
        System.out.println();

    }
}