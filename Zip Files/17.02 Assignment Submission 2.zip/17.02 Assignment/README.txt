PROJECT TITLE: 17.02 Sorting
PURPOSE OF PROJECT: To satisfy the requirements of the 17.02 assignment.
VERSION or DATE: 3/26/17
AUTHORS: V. Swaminathan
COMMENTS: This program took me very little time to write. Although I was confused at first with the bubble sort and insertion sort algorithms, I spent some time studying them until I came to understand how they function. I chose to use the bubble sort method for this assignment, as it seemed the most efficient.