PROJECT TITLE: 9.04 Catapult
PURPOSE OF PROJECT: To satisfy the requirements of the 9.04 challenge assignment.
VERSION or DATE: 3/17/17
AUTHORS: V. Swaminathan
COMMENTS: As I have around two years of background in college-level physics, I was able to quickly write the Catapult class and all its methods. I found that using nested for-loops provided an easy way to go through each element of the 2D array with all the necessary calculations. Other than that, I had no issues.