/**
 * @purpose: To satisfy the requirements of the 9.04 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/17/17
 */

public class CatapultTester
{
    CatapultTester()
    {
        //constructor
    }

    public static void main(String args[])
    {
        //main method --> utlizes a single object to do all calculations
        Catapult testShots = new Catapult(0, 0);

        double currentTestSpeed = 0;

        //arrays of speeds to be used and angles
        double[] speeds = {20, 25, 30, 35, 40, 45, 50};
        double[] angles = {25, 30, 35, 40, 45, 50};

        //rows and columns depend on number of elements provided above
        int ROWS = speeds.length;
        int COLS = angles.length;

        //declaring 2D array of doubles for distances
        Double[][] distances = new Double[ROWS][COLS];

        //nested for loops provide ability to calculate all values from left to right on each row
        for(int i = 0; i < speeds.length; i++)
        {
            currentTestSpeed = speeds[i];
            int currentRow = i;

            for(int test = 0; test < angles.length; test++)
            {
                testShots.modInitials(angles[test], currentTestSpeed);
                testShots.calcDistance();
                distances[currentRow][test] = testShots.getDistance();
            }
        }

        //print statements
        System.out.println("                            Projectile Distance                               ");
        System.out.println("   MPH      25 deg      30 deg      35 deg      40 deg      45 deg      50 deg");
        System.out.println("===============================================================================");

        for(int i = 0; i<speeds.length; i++)
        {
            System.out.printf("%5.2s%6s%6.5s%6s%6.5s%6s%6.5s%6s%6.5s%6s%6.5s%6s%6.5s", speeds[i], " ", distances[i][0], " ", distances[i][1], " ", distances[i][2], " ", distances[i][3], " ", distances[i][4], " ", distances[i][5]);
            System.out.println();
        }


        //Uncomment below for testing single values!!
        //System.out.println(distances[0][0]);
        
    }
}