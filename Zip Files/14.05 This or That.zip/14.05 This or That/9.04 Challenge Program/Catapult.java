/**
 * @purpose: To satisfy the requirements of the 9.04 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/17/17
 * 
 */

public class Catapult
{
    private double Angle, Speed, AngleRads, Distance;

    /**
     * @param angle = angle of launch in degrees
     * @param speed = speed of launch in MPH
     */
    Catapult(double angle, double speed)
    {
        //constructor
        this.Angle = angle;
        this.Speed = speed;
        this.AngleRads = 0;
        this.Distance = 0;
    }

    /**
     * @method calcDistance: calculates distance based on speed and angle
     */
    public void calcDistance()
    {
        this.AngleRads = Math.toRadians(this.Angle);

        this.Distance = (Math.pow(this.Speed, 2)*Math.sin(2*this.AngleRads))/9.8;
    }

    /**
     * @method modInitials: allows for angle and speed of object to be modified
     * @param angle = new angle of launch (in degrees)
     * @param speed = new speed of launch (in MPH)
     */
    public void modInitials(double angle, double speed)
    {
        this.Speed = speed;
        this.Angle = angle;
    }

    /**
     * @method getDistance: accesses distance value from calculation
     */
    public double getDistance()
    {
        return this.Distance;
    }

}