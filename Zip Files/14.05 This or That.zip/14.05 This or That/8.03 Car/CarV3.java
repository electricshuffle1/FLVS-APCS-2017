
/**
 * Purpose: To fulfill the requirements of the 8.03 assignment.
 * 
 * @author V. Swaminathan
 * @version 1/27/2017
 */


public class CarV3
{
    //
    private double Gals;
    private int sMiles;
    private String MakeModel;
    public CarV3(double gals, int sMiles, String makeModel)
        {
            //
            this.Gals = gals;
            this.sMiles = sMiles;
            this.MakeModel = makeModel;
        }
        
    public int calcDistance(int sMiles, int eMiles)
        {
            //
            return eMiles-sMiles;
        }
        
    public double calcMPG(int dist, double gals)
        {
            //
            return ((double)dist)/gals;
        }
        
    public void getInfo(int sMiles, int eMiles, int dist, double MPG)
    {
        //
        System.out.printf("%27s", " ");
        System.out.println("Gas Mileage Calculations");
        System.out.printf("%2s%11s%5s%11s%4s%9s%4s%8s%4s%7s%4s%9s", " ", "Type of Car", " ", "Start Miles", " ", "End Miles", " ", "Distance", " ", "Gallons", " ", "Miles/Gal");
        System.out.println();
        System.out.println("================================================================================================");
        System.out.printf("%2s%1s%11s%6s%8s%5s%8s%9s%3s%7s%4.4s%7s%4.4s", "01", " ", MakeModel, " ", sMiles, " ", eMiles, " ", dist, " ", Gals, " ", MPG);
    }
    
    public static void main(String[] args)
    {
        //
        int startMiles = 55518;
        int endMiles = 0;
        int distance = 0;
        double MPG = 0;
        
        CarV3 car1; 
        car1 = new CarV3(13.2, startMiles, "Honda Civic");
        
        distance = car1.calcDistance(startMiles, 55861);
        endMiles = startMiles + distance;
        MPG = car1.calcMPG(distance, 13.2);
        
        car1.getInfo(startMiles, endMiles, distance, MPG);
    }
}
