/**
 * @purpose: To satisfy the requirements of the 12.04 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/22/17
 */

public class FunctionsTester
{
    public static void main(String[] args)
    {
        Functions test = new Functions();

        double val = 25; //value being tested

        double x = test.calcRecursiveOne(val);
        double y = test.calcRecursiveTwo(val);
        double z = test.calcRecursiveFour(val);

        System.out.println("------------------- Recursive Calls Demo ----------------------");

        System.out.println("The value of the first function is " + x);
        System.out.println("The value of the second function is " + y);
        System.out.println("The value of the fourth function is " + z);


    }
}