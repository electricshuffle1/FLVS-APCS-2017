/**
 * @purpose: To satisfy the requirements of the 12.04 assignment.
 * 
 * @author: V. Swaminathan
 * @version: 3/22/17
 */

public class Functions
{
    public Functions()
    {
        //constructor
    }

    public int calcRecursiveOne(double num)
    {
        if(num <= 10)
        {
            return -7;
        }
        else
        {
            return calcRecursiveOne(num - 4) + 2;
        }
    }

    public int calcRecursiveTwo(double num)
    {
        if(num <= 25)
        {
            return 20;
        }
        else
        {
            return calcRecursiveTwo((num/12) + 5) - 3;
        }
    }

    public int calcRecursiveFour(double num)
    {
        if(num > 20)
        {
            return -100;
        }
        else
        {
            return calcRecursiveFour(num*2) - 4;
        }
    }
}