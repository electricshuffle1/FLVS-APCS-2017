PROJECT TITLE: 14.06 Primes
PURPOSE OF PROJECT: To satisfy the requirements of the 14.06 assignment.
VERSION or DATE: 3/24/17
AUTHORS: V. Swaminathan
COMMENTS: This program was easy to write and understand; I had no issues at all.