/**
 * @purpose: To satisfy the requirements of the 17.04 assignment.
 * 
 * @author V. Swaminathan
 * @version 3/26/17
 */

import java.util.List;
import java.util.ArrayList;
public class TestMovie4
{
    //ArrayList used for holding objects - I know it might be overkill, but I just prefer working with them
    private static List<Movie> myMovies = new ArrayList<Movie>();

    /**
     * @method: printMovies = prints out the toString() info for each element in myMovies
     * 
     * @param null
     */
    public static void printMovies()
    {
        for(Movie m : myMovies)
        {
            System.out.println(m.toString());
        }
    }

    /**
     * @method: sortTitles = sorts elements in myMovies by title, order determined by user
     * 
     * @param low = first index of array to begin sorting from
     * @param high = last index of array to end sorting
     */
    public static void sortTitles(int low, int high)
    {
        if(low == high)
            return;
        
        int mid = (low + high)/2;

        sortTitles(low, mid);
        sortTitles(mid+1, high);
        mergeTitles(low, mid, high);
    }

    /**
     * @method: mergeTitles = merge method --> helps sortTitles
     */
    public static void mergeTitles(int low, int mid, int high)
    {
        Movie[] temp = new Movie[high - low + 1];

        int i = low;
        int j = mid + 1;
        int n = 0;

        while(i <= mid || j <= high)
        {
            if(i > mid)
            {
                temp[n] = myMovies.get(j);
                j++;
            }
            else if(j > high)
            {
                temp[n] = myMovies.get(i);
                i++;
            }
            else if(myMovies.get(i).getTitle().compareTo(myMovies.get(j).getTitle()) < 0)
            {
                temp[n] = myMovies.get(i);
                i++;
            }
            else
            {
                temp[n] = myMovies.get(j);
                j++;
            }
            n++;
        }

        for(int k = low; k <= high; k++)
            myMovies.set(k, temp[k-low]);
    }

    /**
     * @method: sortYears = sorts elements in myMovies by year, order determined by user
     * 
     * @param low = first index of array to sort from
     * @param high = last index of array to stop sort
     */
    public static void sortYears(int low, int high)
    {
        if(low == high)
            return;
        
        int mid = (low + high)/2;

        sortYears(low, mid);
        sortYears(mid+1, high);
        mergeYears(low, mid, high);
    }

    /**
     * @method mergeYears = merge method --> helps sortYears
     */
    public static void mergeYears(int low, int mid, int high)
    {
        Movie[] temp = new Movie[high - low + 1];

        int i = low;
        int j = mid + 1;
        int n = 0;

        while(i <= mid || j <= high)
        {
            if(i > mid)
            {
                temp[n] = myMovies.get(j);
                j++;
            }
            else if(j > high)
            {
                temp[n] = myMovies.get(i);
                i++;
            }
            else if(myMovies.get(i).getYear() > myMovies.get(j).getYear())
            {
                temp[n] = myMovies.get(i);
                i++;
            }
            else
            {
                temp[n] = myMovies.get(j);
                j++;
            }
            n++;
        }

        for(int k = low; k <= high; k++)
            myMovies.set(k, temp[k-low]);
    }

    /**
     * @method: sortStudios = sorts elements in myMovies by studio, order determined by user
     * 
     * @param low = first index of array to sort from
     * @param high = last index of array to stop sort
     */
    public static void sortStudios(int low, int high)
    {
        if(low == high)
            return;
        
        int mid = (low + high)/2;

        sortStudios(low, mid);
        sortStudios(mid+1, high);
        mergeStudios(low, mid, high);
    }

    /**
     * @method: mergeStudios = merge method --> helps sortStudios
     */
    public static void mergeStudios(int low, int mid, int high)
    {
        Movie[] temp = new Movie[high - low + 1];

        int i = low;
        int j = mid + 1;
        int n = 0;

        while(i <= mid || j <= high)
        {
            if(i > mid)
            {
                temp[n] = myMovies.get(j);
                j++;
            }
            else if(j > high)
            {
                temp[n] = myMovies.get(i);
                i++;
            }
            else if(myMovies.get(i).getStudio().compareTo(myMovies.get(j).getStudio()) < 0)
            {
                temp[n] = myMovies.get(i);
                i++;
            }
            else
            {
                temp[n] = myMovies.get(j);
                j++;
            }
            n++;
        }

        for(int k = low; k <= high; k++)
            myMovies.set(k, temp[k-low]);
    }

    public static void main(String[] args)
    {
        myMovies.add(new Movie("The Muppets Take Manhattan", "Columbia Tristar", 2001));
        myMovies.add(new Movie("Mulan Special Edition", "Disney", 2004));
        myMovies.add(new Movie("Shrek 2", "Dreamworks", 2004));
        myMovies.add(new Movie("The Incredibles", "Pixar", 2004));
        myMovies.add(new Movie("Nanny McPhee", "Universal", 2006));
        myMovies.add(new Movie("The Curse of the Were-Rabbit", "Aardman", 2006));
        myMovies.add(new Movie("Ice Age", "20th Century Fox", 2002));
        myMovies.add(new Movie("Lilo & Stitch", "Disney", 2002));
        myMovies.add(new Movie("Robots", "20th Century Fox", 2005));
        myMovies.add(new Movie("Monsters Inc.", "Pixar", 2001));

        //First print
        System.out.println("\nBefore Sorting: ");
        printMovies();
        System.out.println();

        //Sorted by Title - ascending
        System.out.println("\nSorted by Title - ascending: ");
        sortTitles(0, myMovies.size()-1);
        printMovies();
        System.out.println();


        //Sorted by Year - descending
        System.out.println("\nSorted by Year - descending: ");
        sortYears(0, myMovies.size()-1);
        printMovies();
        System.out.println();

        //Sorted by Studio - ascending
        System.out.println("\nSorted by Studio - ascending: ");
        sortStudios(0, myMovies.size()-1);
        printMovies();
        System.out.println();

    }
}