PROJECT TITLE: 16.03 Insertions
PURPOSE OF PROJECT: To satisfy the requirements of the 16.03 assignment.
VERSION or DATE: 3/25/17
AUTHORS: V. Swaminathan
COMMENTS: This program took very little time to write, and by the end, I was able to intuitively understand how to use this algorithm.