PROJECT TITLE: 16.04 Deletions
PURPOSE OF PROJECT: To satisfy the requirements of the 16.04 assignment.
VERSION or DATE: 3/25/17
AUTHORS: V. Swaminathan
COMMENTS: This program took a bit longer to write. Although I was able to follow the lesson, it is not very intuitive when the deletion algorithm is used with standard arrays. The ArrayList version is much more user friendly, in my opinion.